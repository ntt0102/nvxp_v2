<script src="{{ asset('dist/'.str_replace('.', '/', $resourceAlias).'/form.js') }}?update=20190423"></script>
<!-- <script src="{{ asset('plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js') }}?update=20190423"></script> -->
<script src="{{ asset('plugins/richtext/jquery.richtext.min.js') }}?update=20190423"></script>