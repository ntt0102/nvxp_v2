<link rel="stylesheet" href="{{ asset('plugins/richtext/richtext.min.css') }}?update=20190423">
<style type="text/css">
	.richText-toolbar>ul {
		margin-bottom: 0rem;
	}
</style>