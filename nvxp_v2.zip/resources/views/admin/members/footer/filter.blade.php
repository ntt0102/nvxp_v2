<script src="{{ asset('dist/'.str_replace('.', '/', $resourceAlias).'/filter.js') }}?update=20190423"></script>
<script src="{{ asset('dist/_resources/order-by.js') }}?update=20190423"></script>