<!-- <link rel="stylesheet" href="{{ asset('dist/_partials/datepicker/datepicker.css') }}?update=20190423"> -->
<!-- <link rel="stylesheet" href="{{ asset('dist/_partials/avatar/avatar.css') }}?update=20190423"> -->
<link rel="stylesheet" href="{{ asset('dist/_partials/select2/select2.css') }}?update=20190423">
<link rel="stylesheet" href="{{ asset('dist/admin/members/form.css') }}?update=20190423">