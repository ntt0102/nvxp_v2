<script src="{{ asset('plugins/select2/select2.full.min.js') }}?update=20190423"></script>
<script src="{{ asset('dist/_partials/select2/select2.js') }}?update=20190423"></script>
<script src="{{ asset('dist/'.str_replace('.', '/', $resourceAlias).'/form.js') }}?update=20190423"></script>