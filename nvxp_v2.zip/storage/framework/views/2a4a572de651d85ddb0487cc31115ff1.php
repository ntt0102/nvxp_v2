<?php
	$pagesCounter = 0;
	if (count($records) > 0) {
	    $pagesCounter = ceil($records->total()/$records->perPage());
	}
?>
<div class="card-footer clearfix">
	<div class="pagination float-left pt-1">
		<input type="text" id="show" class="text-center" value="<?php echo e($show); ?>" link="<?php echo e($link); ?>"/>
		<span>&nbsp;/&nbsp;<?php echo e($records->total().' '.$_pageTitleLower); ?></span>
	</div>
	<?php if($records->hasPages()): ?>
	    <ul class="pagination pagination-sm m-0 float-right">
	        
	        <?php if($records->onFirstPage()): ?>
	            <li class="page-item disabled"><span class="page-link"><?php echo app('translator')->get('pagination.previous'); ?></span></li>
	        <?php else: ?>
	            <li class="page-item"><a class="page-link" data-page="<?php echo e($records->currentPage() - 1); ?>" href="#" rel="prev"><?php echo app('translator')->get('pagination.previous'); ?></a></li>
	        <?php endif; ?>

	        <?php if($records->currentPage() > 3): ?>
	            <li class="page-item"><a class="page-link" data-page="1" href="#">1</a></li>
	        <?php endif; ?>
	        <?php if($records->currentPage() > 4): ?>
	            <li class="page-item disabled"><span class="page-link">...</span></li>
	        <?php endif; ?>
	        <?php if($records->currentPage() > 2): ?>
	            <li class="page-item"><a class="page-link" data-page="<?php echo e($records->currentPage() - 2); ?>" href="#"><?php echo e($records->currentPage() - 2); ?></a></li>
	        <?php endif; ?>
	        <?php if($records->currentPage() > 1): ?>
	            <li class="page-item"><a class="page-link" data-page="<?php echo e($records->currentPage() - 1); ?>" href="#"><?php echo e($records->currentPage() - 1); ?></a></li>
	        <?php endif; ?>
	        <li class="page-item active"><span class="page-link"><?php echo e($records->currentPage()); ?></span></li>
	        <?php if($records->currentPage() < $pagesCounter): ?>
	            <li class="page-item"><a class="page-link" data-page="<?php echo e($records->currentPage() + 1); ?>" href="#"><?php echo e($records->currentPage() + 1); ?></a></li>
	        <?php endif; ?>
	        <?php if($records->currentPage() < $pagesCounter - 1): ?>
	            <li class="page-item"><a class="page-link" data-page="<?php echo e($records->currentPage() + 2); ?>" href="#"><?php echo e($records->currentPage() + 2); ?></a></li>
	        <?php endif; ?>
	        <?php if($records->currentPage() < $pagesCounter - 3): ?>
	            <li class="page-item disabled"><span class="page-link">...</span></li>
	        <?php endif; ?>
	        <?php if($records->currentPage() < $pagesCounter - 2): ?>
	            <li class="page-item"><a class="page-link" data-page="<?php echo e($pagesCounter); ?>" href="#""><?php echo e($pagesCounter); ?></a></li>
	        <?php endif; ?>

	        
	        <?php if($records->hasMorePages()): ?>
	            <li class="page-item"><a class="page-link" data-page="<?php echo e($records->currentPage() + 1); ?>" href="#" rel="next"><?php echo app('translator')->get('pagination.next'); ?></a></li>
	        <?php else: ?>
	            <li class="page-item disabled"><span class="page-link"><?php echo app('translator')->get('pagination.next'); ?></span></li>
	        <?php endif; ?>
	    </ul>
	<?php endif; ?>
</div>
<?php /**PATH D:\Project\nguyenvanxuanphu\resources\views/common/paginate.blade.php ENDPATH**/ ?>