<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <meta name="robots" content="noindex, nofollow, noarchive">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo $__env->yieldContent('page-title'); ?></title>

    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.1.0/css/all.css">
    <!-- Admin LTE -->
    <link rel="stylesheet" href="<?php echo e(asset('plugins/adminlte/adminlte.min.css')); ?>?update=20190423">
    <!-- Jquery Confirm -->
    <link rel="stylesheet" href="<?php echo e(asset('plugins/jquery-confirm/jquery-confirm.css')); ?>?update=20190423">
    <!-- Google Font: Source Sans Pro -->
    <link href="https://fonts.googleapis.com/css?family=Montserrat:300,400,400i,700" rel="stylesheet">
    <!-- Layout -->
    <link rel="stylesheet" href="<?php echo e(asset('dist/common/common.css')); ?>?update=20190423">
    <link rel="stylesheet" href="<?php echo e(asset('dist/layouts/frontend.css')); ?>?update=20190423">

    <?php echo $__env->yieldContent('head-extras'); ?>
</head>

<!-- ADD THE CLASS layout-top-nav TO REMOVE THE SIDEBAR. -->

<body class="hold-transition">
    <!-- Back to Top -->
    <span id="goTop"><i class="fas fa-angle-up"></i></span>
    <!-- Loading -->
    <div class="load-waiting">
        <div class="text-center text-<?php echo e($skin); ?>">
            <i class="fas fa-circle-notch fa-spin fa-3x"></i>
            <div></div>
        </div>
    </div>
    <!-- Site wrapper -->
    <div class="wrapper" style="background: linear-gradient(rgba(255, 255, 255, 0.6), rgba(0, 0, 0, 0.5)),
    url(<?php echo e(asset('images/background.jpg')); ?>); background-size1: cover;">
        <!-- Header -->
        <?php if ($__env->exists('layouts.partials.frontend.header', ['skin' => $skin])) echo $__env->make('layouts.partials.frontend.header', ['skin' => $skin], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- Content -->
        <div class="content-wrapper">
            <?php if ($__env->exists('flash::message')) echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->yieldContent('content'); ?>
        </div>
        <?php echo $__env->yieldContent('footer'); ?>
    </div>
    <!-- ./wrapper -->

    <!-- REQUIRED SCRIPTS -->
    <!-- jQuery -->
    <script src="<?php echo e(asset('plugins/jquery/jquery.min.js')); ?>?update=20190423"></script>
    <!-- Bootstrap -->
    <script src="<?php echo e(asset('plugins/bootstrap/bootstrap.bundle.min.js')); ?>?update=20190423"></script>
    <!-- AdminLTE -->
    <script src="<?php echo e(asset('plugins/adminlte/adminlte.min.js')); ?>?update=20190423"></script>
    <!-- Jquery Confirm -->
    <script src="<?php echo e(asset('plugins/jquery-confirm/jquery-confirm.js')); ?>?update=20190423"></script>
    <!-- Common -->
    <script src="<?php echo e(asset('dist/common/common.js')); ?>?update=20190423"></script>
    <script src="<?php echo e(asset('dist/layouts/frontend.js')); ?>?update=20190423"></script>

    <!-- OPTIONAL SCRIPTS -->
    <script src="<?php echo e(asset('dist/_partials/cookie/cookie.js')); ?>?update=20190423"></script>
    <script src="<?php echo e(asset('dist/_partials/ajax/ajax.js')); ?>?update=20190423"></script>

    <?php echo $__env->yieldContent('footer-extras'); ?>

    <?php echo $__env->yieldPushContent('footer-scripts'); ?>
</body>

</html><?php /**PATH D:\Project\nguyenvanxuanphu\resources\views/layouts/frontend.blade.php ENDPATH**/ ?>