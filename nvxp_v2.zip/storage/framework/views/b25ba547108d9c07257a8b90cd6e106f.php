<?php
$deleteLink = route('admin::logs.delete');
?>
<div class=" table-responsive">
    <table class="table table-hover">
        <?php if($myUser->role == 2): ?>
        <th style="width: 10px;">
            <div class="custom-control custom-checkbox">
                <input type="checkbox" class="custom-control-input" id="all-id">
                <label class="custom-control-label" for="all-id"></label>
            </div>
        </th>
        <?php endif; ?>
        <th>#</th>
        <th>Loại</th>
        <th>Thành viên</th>
        <th>Tạo lúc</th>
        <th style="min-width: 180px;">Tạo bởi</th>


        <?php $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
        $tableCounter++;
        $userLink = route('admin::members.index', ['id' => $record->member_id]);
        $modifiedLink = route('admin::members.index', ['id' => $record->modified_by]);
        ?>
        <tr>
            <?php if($myUser->role == 2): ?>
            <td>
                <div class="custom-control custom-checkbox">
                    <input type="checkbox" class="custom-control-input" id="del-id-<?php echo e($record->id); ?>" user-id="<?php echo e($record->id); ?>">
                    <label class="custom-control-label" for="del-id-<?php echo e($record->id); ?>"></label>
                </div>
            </td>
            <?php endif; ?>
            <td><?php echo e($tableCounter); ?></td>
            <td>
                <?php switch($record->type):
                case (1): ?>
                <span class="badge bg-primary">
                    <?php break; ?>
                    <?php case (2): ?>
                    <span class="badge bg-success">
                        <?php break; ?>
                        <?php case (3): ?>
                        <span class="badge bg-danger">
                            <?php break; ?>
                            <?php case (4): ?>
                            <span class="badge bg-secondary">
                                <?php break; ?>
                                <?php endswitch; ?>
                                <?php echo e($record->type_name); ?>

                            </span>
            </td>
            <td>
                <?php if($record->member_name): ?>
                <a href="<?php echo e($userLink); ?>"><?php echo e($record->member_name); ?></a>
                <?php else: ?>
                <?php echo e($record->note); ?>

                <?php endif; ?>
            </td>
            <td><?php echo e(date("H:i d/m/Y", strtotime($record->created_at))); ?></td>
            <td><a href="<?php echo e($userLink); ?>"><?php echo e($record->modified_name); ?></a></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    <?php if($myUser->role == 2): ?>
    <form id="formMultiDelete" action="<?php echo e($deleteLink); ?>" method="POST" style="display: none;" class="hidden form-inline">
        <?php echo e(csrf_field()); ?>

        <input type="hidden" id="multiDeleteId" name="id">
    </form>
    <?php endif; ?>
</div><?php /**PATH D:\Project\nguyenvanxuanphu\resources\views/admin/logs/table.blade.php ENDPATH**/ ?>