<?php
$isAdmin = Auth::user()->role == 2;
?>
<div class=" table-responsive">
    <table class="table table-hover">
        <th>#</th>
        <th style="min-width: 100px;">Trạng thái</th>
        <th style="min-width: 150px;">Đối tượng</th>
        <th style="min-width: 200px;">Mô tả</th>
        <th style="min-width: 100px;">Hình ảnh</th>
        <th>Thời gian gửi</th>
        <?php if($isAdmin): ?>
        <th style="min-width: 100px;">Người sửa</th>
        <?php endif; ?>
        <th>
            <div class="text-right">Thao tác<div>
        </th>

        <?php $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
        $tableCounter++;
        //
        $memberLink = route('admin::members.index', ['id' => $record->member_id]);
        if ($isAdmin) {
            $editedUserLink = route('admin::users.index', ['id' => $record->edited_by]);
        }
        //
        if (!$record->edited_by) {
            $processLink = route('admin::proposes.process', $record->id);
            $formProcessId = 'formProcess_' . $record->id;
            $statusName = 'Chưa sửa';
            $statusColor = 'danger';
        } else {
            if ($isAdmin) {
                $deleteLink = route('admin::proposes.delete', $record->id);
                $formDeleteId = 'formDelete_' . $record->id;
            }
            $statusName = 'Đã sửa';
            $statusColor = 'secondary';
        }
        ?>
        <tr>
            <td><?php echo e($tableCounter); ?></td>
            <td><span class="badge badge-<?php echo e($statusColor); ?>"><?php echo e($statusName); ?></span></td>
            <td>
                <?php if($record->member_name): ?>
                <a href="<?php echo e($memberLink); ?>"><?php echo e($record->member_name); ?></a>
                <?php else: ?>
                <span>Không có</span>
                <?php endif; ?>
            </td>
            <td><?php echo preg_replace("/[\n\r]/", '
                <div />', $record->description); ?>

            </td>
            <td>
                <?php if($record->image): ?>
                <img src="<?php echo e(asset('images/proposes/'.$record->image)); ?>" height="40" class="zoom-in">
                <?php else: ?>
                <i class="fas fa-times"></i>
                <?php endif; ?>
            </td>
            <td><?php echo e(date("d/m/Y H:i", strtotime($record->created_at))); ?></td>
            <?php if($isAdmin): ?>
            <td><a href="<?php echo e($editedUserLink); ?>"><?php echo e($record->editor_name); ?></a></td>
            <?php endif; ?>
            <td>
                <div class="float-right input-group-append">
                    <?php if(!$record->edited_by): ?>
                    <button class="btn btn-sm btn-success btnProcess" data-form-id="<?php echo e($formProcessId); ?>" data-name="đề xuất này"><i class="fas fa-edit"></i> Đánh dấu đã sửa</button>
                    <?php elseif($isAdmin): ?>
                    <button class="btn btn-sm btn-danger btnDelete" data-form-id="<?php echo e($formDeleteId); ?>" data-name="đề xuất này"><i class="fas fa-trash-alt"></i> Xóa</button>
                    <?php endif; ?>
                </div>
                <?php if(!$record->edited_by): ?>
                <form id="<?php echo e($formProcessId); ?>" action="<?php echo e($processLink); ?>" method="POST" class="hide form-inline">
                    <?php echo e(csrf_field()); ?>

                    <input type="hidden" name="classifies" />
                </form>
                <?php elseif($isAdmin): ?>
                <form id="<?php echo e($formDeleteId); ?>" action="<?php echo e($deleteLink); ?>" method="POST" class="hide form-inline">
                    <?php echo e(csrf_field()); ?>

                    <input type="hidden" name="classifies" />
                </form>
                <?php endif; ?>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</div><?php /**PATH D:\Project\nguyenvanxuanphu\resources\views/admin/proposes/table.blade.php ENDPATH**/ ?>