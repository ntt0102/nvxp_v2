<?php
$skin = App\Utils::getColor()->skin;
$_pageTitle = 'Gia huấn ca';
?>



<?php $__env->startSection('page-title', $_pageTitle); ?>
<?php $__env->startSection('head-extras'); ?>
<link rel="stylesheet" href="<?php echo e(asset('dist/general/teaching/teaching.css')); ?>?update=20190423">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row justify-content-center" style="padding: 0 10px;">
	<div class="col-md-12">
		<h3 class="title">Gia huấn ca</h3>
		<div class="card card-<?php echo e($skin); ?> card-outline">
			<div class="card-body">
				<?php echo $content; ?>

			</div>
			<?php if(auth()->guard()->check()): ?>
			<?php if(Auth::user()->role == 2): ?>
			<div class="card-footer">
				<a target="_blank" class="load-none" href="<?php echo e(route('admin::constants.edit', 3)); ?>">Chỉnh sửa <i class="far fa-edit"></i></a>
			</div>
			<?php endif; ?>
			<?php endif; ?>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', ['skin' => $skin], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\nguyenvanxuanphu\resources\views/general/teaching.blade.php ENDPATH**/ ?>