<?php
$color = App\Utils::getColor();
?>




<?php
$resourceTitle = "Đổi mật khẩu";
$_pageTitle = ucfirst($resourceTitle);
$_storeLink = route($resourceRoutesAlias . '.change-password');
//
$myUser = Auth::user();
?>


<?php $__env->startSection('breadcrumbs'); ?>
<?php echo Breadcrumbs::render($resourceRoutesAlias.'.change-password'); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('page-title', $_pageTitle); ?>




<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <div class="card card-skin card-<?php echo e($color->skin); ?> card-outline">
            <form class="form" role="form" method="POST" action="<?php echo e($_storeLink); ?>">
                <?php echo e(csrf_field()); ?>

                <?php echo e(redirect_back_field()); ?>


                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="oldpassword" class="form-control-label">Mật khẩu hiện tại</label>
                                        <input id="oldpassword" type="password" class="form-control<?php echo e($errors->has('oldpassword') ? ' is-invalid' : ''); ?>" name="oldpassword" value="<?php echo e(old('oldpassword')); ?>" autofocus>
                                        <?php if($errors->has('oldpassword')): ?>
                                        <div class="invalid-feedback">Mật khẩu hiện tại
                                            <?php echo e($errors->first('oldpassword')); ?>

                                        </div>
                                        <?php endif; ?>
                                    </div>
                                    <!-- /.form-group -->
                                </div>
                                <!-- col-md-12 -->
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="password" class="form-control-label">Mật khẩu mới</label>
                                        <input id="password" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" <?php echo e(!$errors->has('oldpassword') && $errors->has('password') ? 'autofocus' : ''); ?>>
                                        <?php if($errors->has('password')): ?>
                                        <div class="invalid-feedback">Mật khẩu mới <?php echo e($errors->first('password')); ?>

                                        </div>
                                        <?php endif; ?>
                                    </div>
                                    <!-- /.form-group -->
                                </div>
                                <!-- col-md-12 -->
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="password-confirm" class="form-control-label">Nhập lại mật khẩu
                                            mới</label>
                                        <input id="password-confirm" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password_confirmation">
                                    </div>
                                    <!-- /.form-group -->
                                </div>
                                <!-- col-md-12 -->
                            </div>
                            <!-- row -->
                        </div>
                        <!-- /.col-md-12 -->
                    </div>
                </div>
                <!-- /.card-body -->
                <div class="card-footer clearfix">
                    <div class="row">
                        <div class="col-md-12">
                            <button class="btn btn-skin btn-success">
                                <i class="fas fa-save"></i> <span>Lưu</span>
                            </button>
                        </div>
                        <!-- /.col-md-9 -->
                    </div>
                    <!-- /.row -->
                </div>
                <!-- /.card-footer -->
            </form>
            <!-- /form -->
        </div>
        <!-- /.card -->
    </div>
</div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.backend', ['theme' => $color->theme, 'skin' => $color->skin], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\nguyenvanxuanphu\resources\views/admin/users/change-password.blade.php ENDPATH**/ ?>