<?php
$color = App\Utils::getColor();
?>




<?php
$_pageTitle = ucfirst($resourceTitle);
$_formFiles = isset($classifies['formFiles']) ? $classifies['formFiles'] : false;
$_listLink = route($resourceRoutesAlias . '.index');
$_createLink = route($resourceRoutesAlias . '.create');
$_updateLink = route($resourceRoutesAlias . '.update', $record->id);
$deleteLink = route($resourceRoutesAlias . '.destroy', $record->id);
//
$myUser = Auth::user();
?>


<?php $__env->startSection('breadcrumbs'); ?>
<?php echo Breadcrumbs::render($resourceRoutesAlias.'.edit', $resourceTitle, $record->id); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('page-title', $_pageTitle); ?>



<?php $__env->startSection('head-extras'); ?>
<?php if ($__env->exists($resourceAlias.'.header.form')) echo $__env->make($resourceAlias.'.header.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <div class="card card-skin card-<?php echo e($color->skin); ?> card-outline">
            <form class="form" role="form" method="POST" action="<?php echo e($_updateLink); ?>" enctype="<?php echo e($_formFiles === true ? 'multipart/form-data' : ''); ?>">
                <?php echo e(csrf_field()); ?>

                <?php echo e(method_field('PUT')); ?>

                <?php echo e(redirect_back_field()); ?>


                <div class="card-header">
                    <h3 class="card-title">&nbsp;<span class="d-none d-sm-inline-block"><?php echo e($editSubtitle); ?></span></h3>
                    <div class="card-tools">
                        <span id="btnList" data-link="<?php echo e($_listLink); ?>" class="btn btn-sm btn-skin btn-<?php echo e($color->skin); ?> mr-1">
                            <?php echo $listButtonName; ?>

                        </span>
                        <span id="btnCreate" data-link="<?php echo e($_createLink); ?>" class="btn btn-sm btn-skin btn-<?php echo e($color->skin); ?> mr-1">
                            <?php echo $createButtonName; ?>

                        </span>
                    </div>
                    <!-- /.card-tools -->
                </div>
                <!-- /.card-header -->
                <div class="card-body">
                    <div class="row">
                        <?php if ($__env->exists($resourceAlias.'.form')) echo $__env->make($resourceAlias.'.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                </div>
                <!-- /.card-body -->
                <div class="card-footer clearfix">
                    <div class="row">
                        <div class="col-md-12">
                            <button class="btn btn-skin btn-success">
                                <i class="fas fa-save"></i> <span>Lưu</span>
                            </button>
                            <span id="btnCancel" data-link="<?php echo e($_listLink); ?>" class="btn btn-secondary ml-3 load">
                                <i class="fas fa-ban"></i> <span>Hủy</span>
                            </span>
                            <span id="btnDelete" class="btn btn-danger ml-3 float-right">
                                <i class="fas fa-trash-alt"></i> <span>Xóa</span>
                            </span>
                        </div>
                        <!-- /.col-md-9 -->
                    </div>
                    <!-- /.row -->
                </div>
                <!-- /.card-footer -->
            </form>
            <!-- /form -->
            <form id="formDelete" action="<?php echo e($deleteLink); ?>" method="POST" class="hide form-inline">
                <?php echo e(csrf_field()); ?>

                <?php echo e(method_field('DELETE')); ?>

            </form>
        </div>
        <!-- /.card -->
    </div>
</div>
<div class="row">
    <div class="col-12">
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('footer-extras'); ?>
<script src="<?php echo e(asset('dist/_resources/form.js')); ?>?update=20190423"></script>
<?php if ($__env->exists($resourceAlias.'.footer.form')) echo $__env->make($resourceAlias.'.footer.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend', ['theme' => $color->theme, 'skin' => $color->skin], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\nguyenvanxuanphu\resources\views/_resources/edit.blade.php ENDPATH**/ ?>