<?php
$skin = App\Utils::getColor()->skin;
?>
<!--  -->


<?php $__env->startSection('page-title', 'Đăng nhập'); ?>


<?php $__env->startSection('content'); ?>
<div class="login-box mb-5">
  <div class="card card-<?php echo e($skin); ?> card-outline">
    <div class="card-header">
      <h3 class="card-title text-center"><span>Đăng nhập</span></h3>
    </div>
    <!-- /.card-header -->
    <div class="card-body">
      <form method="POST" action="<?php echo e(route('login')); ?>">
        <?php echo e(csrf_field()); ?>


        <div class="row">
          <div class="col-md-12">
            <div class="form-group">
              <label for="login" class="control-label">Tên đăng nhập | Email</label>
              <input id="login" type="text" class="form-control<?php echo e($errors->has('username') || $errors->has('email') ? ' is-invalid' : ''); ?>" name="login" value="<?php echo e(old('username') ?: old('email')); ?>" required autofocus onfocus="var temp_value=this.value; this.value=''; this.value=temp_value">

              <?php if($errors->has('username') || $errors->has('email')): ?>
              <span class="invalid-feedback">
                <strong><?php echo e($errors->first('username') ?: $errors->first('email')); ?></strong>
              </span>
              <?php endif; ?>
            </div>
            <!-- /.form-group -->
          </div>
          <!-- col-md-12 -->
        </div>
        <!-- row -->
        <div class="row">
          <div class="col-md-12">
            <div class="form-group">
              <label for="password" class="control-label">Mật khẩu</label>
              <input id="password" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" required>

              <?php if($errors->has('password')): ?>
              <span class="invalid-feedback">
                <strong><?php echo e($errors->first('password')); ?></strong>
              </span>
              <?php endif; ?>
            </div>
            <!-- /.form-group -->
          </div>
          <!-- col-md-12 -->
        </div>
        <!-- row -->
        <div class="row">
          <div class="col-md-12">
            <div class="form-group">
              <div class="custom-control custom-checkbox">
                <input type="checkbox" class="custom-control-input" id="remember" name="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
                <label class="custom-control-label" for="remember">Ghi nhớ đăng nhập</label>
              </div>
              <!-- /.custom-control -->
            </div>
            <!-- /.form-group -->
          </div>
          <!-- col-md-12 -->
        </div>
        <!-- row -->
        <div class="row">
          <div class="col-md-6">
            <div class="form-group">
              <button type="submit" class="btn btn-<?php echo e($skin); ?>">Đăng nhập</button>
            </div>
            <!-- /.form-group -->
          </div>
          <!-- col-md-6 -->
        </div>
        <!-- row -->
      </form>
      <!-- /form -->
    </div>
    <!-- /.card-body -->
    <div class="card-footer">
      <a href="<?php echo e(route('password.request')); ?>" id="resetPassword" class="text-center">Quên mật khẩu</a>
    </div>
    <!-- /.card-footer -->
  </div>
  <!-- /.card -->
</div>
<!-- /.login-box -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', ['skin' => $skin], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\nguyenvanxuanphu\resources\views/auth/login.blade.php ENDPATH**/ ?>