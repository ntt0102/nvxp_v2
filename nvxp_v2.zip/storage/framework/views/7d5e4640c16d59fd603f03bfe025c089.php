<?php $__env->startSection('head-extras'); ?>
    <style>
        body{
            background: var(--<?php echo e($skin); ?>);
            color: #<?php echo e($skin == 'warning' ? '000' :'fff'); ?>;
        }
        .navbar {
            background: var(--<?php echo e($skin); ?>);
        }
        hr {
            border-top: 5px solid #<?php echo e($skin == 'warning' ? '000' :'fff'); ?> !important;
        }
        hr:after {
            background: var(--<?php echo e($skin); ?>);
        }
        .btn {
            color: var(--<?php echo e($skin); ?>);
        }
    </style>
  <link rel="stylesheet" href="<?php echo e(asset('/dist/layouts/error.css')); ?>?update=20190505">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div id="clouds">
        <div class="cloud x1"></div>
        <div class="cloud x1_5"></div>
        <div class="cloud x2"></div>
        <div class="cloud x3"></div>
        <div class="cloud x4"></div>
        <div class="cloud x5"></div>
    </div>
    <div class='c'>
        <div class='_404'><?php echo $__env->yieldContent('code'); ?></div>
        <hr>
        <div class='_1'><?php echo $__env->yieldContent('message'); ?></div>
        <div class='_2'>&nbsp;</div>
        <a class='btn' href="<?php echo e(route('admin::index')); ?>">QUAY LẠI</a>
    </div>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.frontend', ['skin' => $skin], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\nguyenvanxuanphu\resources\views/layouts/errors.blade.php ENDPATH**/ ?>