<?php
$color = App\Utils::getColor();
//
$myUser = Auth::user();

$showResult = true;
switch ($classifies['filterMode']) {
  case 'base':
  case 'view':
    $url = route('map');
    $fnc = '1';
    $ajax = '';
    break;
  case 'branch':
    $url = route('admin::members.create') . "?filterMode=" . $classifies['filterMode'];
    $fnc = '2';
    $ajax = route('admin::classifies.branch');
    break;
  case 'modify':
    $url = route('admin::members.index');
    $fnc = '3';
    $ajax = '';
    $showResult = false;
    break;
  case 'manager':
    $url = route('admin::users.create');
    $fnc = '3';
    $ajax = '';
    break;
  case 'statistic':
    $url = route('statistic');
    $fnc = '3';
    $ajax = '';
    break;
  default:
    $url = '';
    $fnc = '';
    $ajax = '';
}
?>





<?php $__env->startSection('page-title', 'Tìm kiếm'); ?>


<?php $__env->startSection('head-extras'); ?>
<link rel="stylesheet" href="<?php echo e(asset('dist/_partials/select2/select2.css')); ?>?update=20190423">
<link rel="stylesheet" href="<?php echo e(asset('dist/general/filter/filter.css')); ?>?update=20190423">
<?php if(count($records)): ?>
<link rel="stylesheet" href="<?php echo e(asset('dist/_partials/pagination/pagination.css')); ?>?update=20190423">
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<input type="hidden" id="url" value="<?php echo e($url); ?>" fnc="<?php echo e($fnc); ?>" ajax="<?php echo e($ajax); ?>">
<div class="row" style="padding: 10px;">
  <div class="col-md-4">
    <form action="<?php echo e(route('filter')); ?>" method="get">
      <div class="card card-<?php echo e($color->skin); ?> card-outline">
        <div class="card-header">
          <h3 class="card-title">
            <i class="fas fa-filter"></i>
            Bộ lọc
          </h3>
          <div class="card-tools">
            <button id="btnFilter" type="button" class="btn btn-tool" data-widget="collapse"><i class="fa fa-minus"></i>
            </button>
          </div>
        </div>
        <div class="card-body">
          <div class="row">
            <div class="col-12">
              <div class="form-group-sm">
                <label for="filterMode" style="width: 80px;">Loại: </label>
                <select id="filterMode" name="filterMode" style="width: calc(100% - 80px - 5px); height: 30px;">
                  <option value="">&nbsp;</option>
                  <?php $__currentLoopData = $classifies['filterModes']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $filterMode): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($filterMode->value); ?>" <?php echo e($classifies['filterMode'] == $filterMode->value ? 'selected' : ''); ?>><?php echo e($filterMode->name); ?>

                  </option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
              <!-- /.form-group -->
            </div>
            <!-- /.col -->
            <div class="col-12">
              <div class="form-group-sm">
                <label for="id" style="width: 80px;">ID: </label>
                <input id="id" type="text" style="width: calc(100% - 80px - 5px);" name="id" value="<?php echo e($classifies['id']); ?>" <?php echo e($classifies['id'] ? 'autofocus' : ''); ?> onfocus="var temp_value=this.value; this.value=''; this.value=temp_value">
              </div>
              <!-- /.form-group -->
            </div>
            <!-- /.col -->
            <div class="col-12">
              <div class="form-group-sm">
                <label for="name" style="width: 80px;">Họ tên: </label>
                <input id="name" type="text" style="width: calc(100% - 80px - 5px);" name="name" value="<?php echo e($classifies['name']); ?>" <?php echo e(!($classifies['id'] || $classifies['parent'] || $classifies['couple']) ? 'autofocus' : ''); ?> onfocus="var temp_value=this.value; this.value=''; this.value=temp_value">
              </div>
              <!-- /.form-group -->
            </div>
            <!-- /.col -->
            <div class="col-12">
              <div class="form-group-sm">
                <label for="pedigree" style="width: 80px;">Hệ: </label>
                <select id="pedigree" name="pedigree" style="width: calc(100% - 80px - 5px); height: 30px;">
                  <option value="">&nbsp;</option>
                  <?php for($i = 1; $i <= $classifies['pedigrees']; $i++): ?> <option value="<?php echo e($i); ?>" <?php echo e($classifies['pedigree'] == $i ? 'selected' : ''); ?>><?php echo e($i); ?></option>
                    <?php endfor; ?>
                </select>
              </div>
              <!-- /.form-group -->
            </div>
            <!-- /.col -->
            <div class="col-12">
              <div class="form-group-sm">
                <label for="relation" style="width: 80px;">Quan hệ: </label>
                <select id="relation" name="relation" style="width: calc(100% - 80px - 5px); height: 30px;">
                  <option value="">&nbsp;</option>
                  <?php $__currentLoopData = $classifies['relations']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $relation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($relation->value); ?>" <?php echo e($classifies['relation'] == $relation->value ? 'selected' : ''); ?>><?php echo e($relation->name); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
              <!-- /.form-group -->
            </div>
            <!-- /.col -->
            <div class="col-12">
              <div class="form-group-sm">
                <label for="parent" style="width: 80px;">Cha: </label>
                <input id="parent" type="text" style="width: calc(100% - 80px - 5px);" name="parent" value="<?php echo e($classifies['parent']); ?>" <?php echo e($classifies['parent'] ? 'autofocus' : ''); ?> onfocus="var temp_value=this.value; this.value=''; this.value=temp_value">
              </div>
              <!-- /.form-group -->
            </div>
            <!-- /.col -->
            <div class="col-12">
              <div class="form-group-sm">
                <label for="couple" style="width: 80px;">Chồng: </label>
                <input id="couple" type="text" style="width: calc(100% - 80px - 5px);" name="couple" value="<?php echo e($classifies['couple']); ?>" <?php echo e($classifies['couple'] ? 'autofocus' : ''); ?> onfocus="var temp_value=this.value; this.value=''; this.value=temp_value">
              </div>
              <!-- /.form-group -->
            </div>
            <!-- /.col -->
            <div class="col-12">
              <div class="form-group-sm">
                <label for="note" style="width: 80px;">Ghi chú: </label>
                <input id="note" type="text" style="width: calc(100% - 80px - 5px);" name="note" value="<?php echo e($classifies['note']); ?>" <?php echo e($classifies['note'] ? 'autofocus' : ''); ?> onfocus="var temp_value=this.value; this.value=''; this.value=temp_value">
              </div>
              <!-- /.form-group -->
            </div>
            <!-- /.col -->
          </div>
          <!-- /.row -->
        </div>
        <!-- /.card-body-->
        <div class="card-footer clearfix">
          <div class="row">
            <div class="col-md-12">
              <input type="hidden" name="base" value="<?php echo e($classifies['base']); ?>" />
              <input type="hidden" name="view" value="<?php echo e($classifies['view']); ?>" />
              <span class="btn btn-secondary" onclick="event.preventDefault(); window.history.back();">
                <i class="fas fa-undo"></i> <span>Trở về</span>
              </span>
              <button type="button" class="btn btn-<?php echo e($color->skin); ?> float-right" onclick="filterOrRedirect()">
                <i class="fas fa-search"></i> <span>Tìm kiếm</span>
              </button>
            </div>
            <!-- /.col-md-9 -->
          </div>
          <!-- /.row -->
        </div>
        <!-- /.card-footer -->
      </div>
      <!-- /.card -->
    </form>
  </div>
  <div class="col-md-8">
    <div class="card card-<?php echo e($color->skin); ?> card-outline">
      <div class="card-header">
        <h3 class="card-title">
          <i class="fas fa-list-ul"></i>
          Kết quả
        </h3>
        <div class="card-tools">
          <button type="button" class="btn btn-tool" data-widget="collapse"><i class="fa fa-minus"></i>
          </button>
        </div>
      </div>
      <div class="card-body">
        <?php if($showResult): ?>
        <?php if(count($records) > 0): ?>
        <?php $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
        if ($record->gender == 1) {
          if ($record->pedigree == 1) {
            $relationName = 'Ông tổ';
          } else {
            $relationName = 'Con trai';
          }
        } else {
          if ($record->couple_id) {
            if ($record->pedigree == 1) {
              $relationName = 'Bà tổ';
            } else {
              $relationName = 'Con dâu';
            }
          } else {
            $relationName = 'Con gái';
          }
        }
        ?>
        <div class="card result-item" style="width:" dataId="<?php echo e($record->id); ?>" dataName="<?php echo e($record->name); ?>" dataPedigree="<?php echo e($record->pedigree); ?>" dataGender="<?php echo e($record->gender); ?>">
          <div class="card-body">
            <h4 class="card-title" style="font-size: 1.5em;"><?php echo e($record->name); ?></h4>
            <p class="card-text">
              <?php if(!Auth::guest()): ?>
              ID: <?php echo e($record->id); ?>

              <br>
              <?php endif; ?>
              Hệ: <?php echo e($record->pedigree); ?>

              <br>
              Quan hệ: <?php echo e($relationName); ?>

              <?php if($record->parent_name): ?>
              <br>
              Cha: <?php echo e($record->parent_name); ?>

              <?php endif; ?>
              <?php if($record->couple_name): ?>
              <br>
              <?php echo e($record->gender == '1' ? 'Vợ' : 'Chồng'); ?>: <?php echo e($record->couple_name); ?>

              <?php endif; ?>
              <?php if($record->note && $classifies['note']): ?>
              <br>
              Ghi chú: <?php echo e($record->note); ?>

              <?php endif; ?>
            </p>
          </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
        <?php if($classifies['isExecuted'] == 1): ?>
        <div>Kết quả không tìm thấy.</div>
        <?php else: ?>
        <div>Hãy nhập thông tin để tìm kiếm.</div>
        <?php endif; ?>
        <?php endif; ?>
        <?php else: ?>
        <div>Nhấn Tìm kiếm để hiển thị kết quả ở trang danh sách.</div>
        <?php endif; ?>
      </div>
      <!-- /.card-body-->
      <?php if($showResult): ?>
      <?php if(count($records)): ?>
      <?php $_pageTitleLower = 'kết quả'; ?>
      <?php if ($__env->exists('common.paginate', ['records' => $records, 'show' => $classifies['show'], 'link' => route('filter')])) echo $__env->make('common.paginate', ['records' => $records, 'show' => $classifies['show'], 'link' => route('filter')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <?php endif; ?>
      <?php endif; ?>
    </div>
    <!-- /.card -->
  </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('footer-extras'); ?>
<script src="<?php echo e(asset('plugins/select2/select2.full.min.js')); ?>?update=20190423"></script>
<script src="<?php echo e(asset('dist/_partials/select2/select2.js')); ?>?update=20190423"></script>
<script src="<?php echo e(asset('dist/general/filter/filter.js')); ?>?update=20190423"></script>
<?php if(count($records)): ?>
<script src="<?php echo e(asset('dist/_partials/pagination/pagination.js')); ?>?update=20190423"></script>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', ['theme' => $color->theme, 'skin' => $color->skin], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\nguyenvanxuanphu\resources\views/general/filter.blade.php ENDPATH**/ ?>