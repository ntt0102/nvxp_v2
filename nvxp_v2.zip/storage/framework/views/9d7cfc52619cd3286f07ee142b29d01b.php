<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <meta name="robots" content="noindex, nofollow, noarchive">

  <!-- CSRF Token -->
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
  <meta name="user-id" content="<?php echo e(Auth::user()->id); ?>">
  <meta name="user-role" content="<?php echo e(Auth::user()->role); ?>">

  <title><?php if (! empty(trim($__env->yieldContent('page-title')))): ?> <?php echo $__env->yieldContent('page-title'); ?> <?php endif; ?></title>

  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.1.0/css/all.css">
  <!-- Admin LTE -->
  <link rel="stylesheet" href="<?php echo e(asset('plugins/adminlte/adminlte.min.css')); ?>?update=20190423">
  <!-- Jquery Confirm -->
  <link rel="stylesheet" href="<?php echo e(asset('plugins/jquery-confirm/jquery-confirm.css')); ?>?update=20190423">
  <!-- Google Font: Source Sans Pro -->
  <link href="https://fonts.googleapis.com/css?family=Montserrat:300,400,400i,700" rel="stylesheet">
  <!-- Layout -->
  <link rel="stylesheet" href="<?php echo e(asset('dist/common/common.css')); ?>?update=20190423">
  <link rel="stylesheet" href="<?php echo e(asset('dist/layouts/backend.css')); ?>?update=20190423">

  <?php echo $__env->yieldContent('head-extras'); ?>
</head>

<!-- ADD THE CLASS layout-top-nav TO REMOVE THE SIDEBAR. -->

<body class="hold-transition sidebar-mini">
  <!-- Back to Top -->
  <span id="goTop"><i class="fas fa-angle-up"></i></span>
  <!-- Loading -->
  <div class="load-waiting">
    <div class="text-center text-<?php echo e($skin); ?>">
      <i class="fas fa-circle-notch fa-spin fa-3x"></i>
      <div></div>
      <datalist class="ajax">
      </datalist>
    </div>
  </div>

  <!-- Site wrapper -->
  <div class="wrapper">
    <!-- Header -->
    <?php if ($__env->exists('layouts.partials.backend.header', ['theme' => $theme, 'skin' => $skin])) echo $__env->make('layouts.partials.backend.header', ['theme' => $theme, 'skin' => $skin], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Main Sidebar -->
    <?php if ($__env->exists('layouts.partials.backend.main-sidebar', ['theme' => $theme, 'skin' => $skin])) echo $__env->make('layouts.partials.backend.main-sidebar', ['theme' => $theme, 'skin' => $skin], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <div class="content-header">
        <div class="container-fluid">
          <div class="row mb-2">
            <div class="col-sm-6">
              <h1 class="m-0 text-dark">
                <?php echo $__env->yieldContent('page-title'); ?>
              </h1>
            </div><!-- /.col -->
            <div class="col-sm-6">
              <?php echo $__env->yieldContent('breadcrumbs'); ?>
            </div><!-- /.col -->
          </div><!-- /.row -->
        </div><!-- /.container-fluid -->
      </div>
      <!-- /.content-header -->

      <!-- Main content -->
      <div class="content">
        <div class="container-fluid">
          <?php if ($__env->exists('flash::message')) echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

          <?php echo $__env->yieldContent('content'); ?>
        </div>
        <!-- /.container-fluid -->
      </div>
      <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
    <?php if ($__env->exists('layouts.partials.backend.control-sidebar', ['theme' => $theme, 'skin' => $skin])) echo $__env->make('layouts.partials.backend.control-sidebar', ['theme' => $theme, 'skin' => $skin], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </div>
  <!-- ./wrapper -->

  <!-- REQUIRED SCRIPTS -->
  <!-- jQuery -->
  <script src="<?php echo e(asset('plugins/jquery/jquery.min.js')); ?>?update=20190423"></script>
  <!-- Bootstrap -->
  <script src="<?php echo e(asset('plugins/bootstrap/bootstrap.bundle.min.js')); ?>?update=20190423"></script>
  <!-- AdminLTE -->
  <script src="<?php echo e(asset('plugins/adminlte/adminlte.min.js')); ?>?update=20190423"></script>
  <!-- Jquery Confirm -->
  <script src="<?php echo e(asset('plugins/jquery-confirm/jquery-confirm.js')); ?>?update=20190423"></script>
  <!-- Common -->
  <script src="<?php echo e(asset('dist/common/common.js')); ?>?update=20190423"></script>
  <script src="<?php echo e(asset('dist/layouts/backend.js')); ?>?update=20190423"></script>

  <!-- OPTIONAL SCRIPTS -->
  <script src="<?php echo e(asset('dist/_partials/cookie/cookie.js')); ?>?update=20190423"></script>
  <script src="<?php echo e(asset('dist/_partials/ajax/ajax.js')); ?>?update=20190423"></script>

  <?php echo $__env->yieldContent('footer-extras'); ?>

  <?php echo $__env->yieldPushContent('footer-scripts'); ?>
</body>

</html><?php /**PATH D:\Project\nguyenvanxuanphu\resources\views/layouts/backend.blade.php ENDPATH**/ ?>