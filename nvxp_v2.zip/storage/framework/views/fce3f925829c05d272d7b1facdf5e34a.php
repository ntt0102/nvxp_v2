<?php
$color = App\Utils::getColor();
?>




<?php
$_pageTitle = 'Chạy lệnh';
$_pageTitleLower = mb_strtolower($_pageTitle);
$resourceAlias = 'admin.command';
$resourceRoutesAlias = 'admin::command';
$commandLink = route($resourceRoutesAlias . '.do');
$myUser = Auth::user();
?>


<?php $__env->startSection('breadcrumbs'); ?>
<?php echo Breadcrumbs::render($resourceRoutesAlias); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('page-title', $_pageTitle); ?>


<?php $__env->startSection('head-extras'); ?>
<link rel="stylesheet" href="<?php echo e(asset('dist/_partials/select2/select2.css')); ?>?update=20190423">
<link rel="stylesheet" href="<?php echo e(asset('dist/admin/command/command.css')); ?>?update=20190423">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <div class="card card-skin card-<?php echo e($color->skin); ?> card-outline">
            <div class="card-body">
                <div class="row">
                    <?php if ($__env->exists($resourceAlias.'.form')) echo $__env->make($resourceAlias.'.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
            <!-- /.card-body -->
            <div class="card-footer clearfix">
                <div class="row">
                    <div class="col-md-12">
                        <button id="btnCommand" class="btn btn-skin btn-success">
                            <i class="fas fa-terminal"></i> <span>Thực thi</span>
                        </button>
                    </div>
                    <!-- /.col-md-9 -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /.card-footer -->
        </div>
        <!-- /.card -->
    </div>
    <!-- /.col-md-9 -->
</div>
<!-- /.row -->
<?php $__env->stopSection(); ?>


<?php $__env->startSection('footer-extras'); ?>
<script src="<?php echo e(asset('plugins/select2/select2.full.min.js')); ?>?update=20190423"></script>
<script src="<?php echo e(asset('dist/_partials/select2/select2.js')); ?>?update=20190423"></script>
<script src="<?php echo e(asset('dist/admin/command/command.js')); ?>?update=20190423"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend', ['theme' => $color->theme, 'skin' => $color->skin], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\nguyenvanxuanphu\resources\views/admin/command/index.blade.php ENDPATH**/ ?>