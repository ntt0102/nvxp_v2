<script src="<?php echo e(asset('plugins/datepicker/bootstrap-datepicker.min.js')); ?>?update=20190423"></script>
<script src="<?php echo e(asset('dist/_partials/datepicker/datepicker.js')); ?>?update=20190423"></script>
<script src="<?php echo e(asset('plugins/croppie/croppie.js')); ?>?update=20190423"></script>
<script src="<?php echo e(asset('dist/_partials/avatar/avatar.js')); ?>?update=20190423"></script>
<script src="<?php echo e(asset('plugins/select2/select2.full.min.js')); ?>?update=20190423"></script>
<script src="<?php echo e(asset('dist/_partials/select2/select2.js')); ?>?update=20190423"></script>
<script src="<?php echo e(asset('dist/'.str_replace('.', '/', $resourceAlias).'/form.js')); ?>?update=20190423"></script><?php /**PATH D:\Project\nguyenvanxuanphu\resources\views/admin/members/footer/form.blade.php ENDPATH**/ ?>