<div class="table-responsive">
    <table class="table table-hover">
        <th>#</th>
        <th style="min-width: 180px;">Họ và tên</th>
        <th>Hệ</th>
        <th style="min-width: 90px;">Email</th>
        <th style="min-width: 40px;">Vai trò</th>
        <th style="width: 90px;">
            <div class="text-left">Thao tác</div>
        </th>

        <?php $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
        $tableCounter++;
        //
        $viewLink = route('map') . '?view=' . $record->id;
        $editLink = route($resourceRoutesAlias . '.edit', $record->id);
        $deleteLink = route($resourceRoutesAlias . '.destroy', $record->id);
        $formDeleteId = 'formDestroyToggle_' . $record->id;
        ?>
        <tr>
            <td><?php echo e($tableCounter); ?></td>
            <td><?php echo e($record->name); ?></td>
            <td><?php echo e($record->pedigree); ?></td>
            <td><?php echo e($record->email); ?></td>
            <td><?php echo e($record->role_name); ?></td>
            <!-- we will also add show, edit, and delete buttons -->
            <td>
                <div class="float-left input-group-append">
                    <button class="ml-1 btn btn-sm btn-primary btnEdit" data-url="<?php echo e($editLink); ?>"><i class="fas fa-edit"></i> Sửa</button>
                    <?php if(Auth::user()->id != $record->id): ?>
                    <button class="ml-1 btn btn-sm btn-danger btnDelete" data-form-id="<?php echo e($formDeleteId); ?>" data-name="<?php echo e($record->name); ?>"><i class="fas fa-trash-alt"></i> Xóa</button>
                    <?php endif; ?>
                </div>
                <?php if(Auth::user()->id != $record->id): ?>
                <form id="<?php echo e($formDeleteId); ?>" action="<?php echo e($deleteLink); ?>" method="POST" class="hide form-inline">
                    <?php echo e(csrf_field()); ?>

                    <?php echo e(method_field('DELETE')); ?>

                    <input type="hidden" name="classifies" />
                </form>
                <?php endif; ?>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div><?php /**PATH D:\Project\nguyenvanxuanphu\resources\views/admin/users/table.blade.php ENDPATH**/ ?>