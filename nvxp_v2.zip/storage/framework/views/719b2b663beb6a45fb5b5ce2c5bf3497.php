<?php if($link): ?>
	<?php
		if(!isset($placeholder)) $placeholder = 'Tìm kiếm';
	?>
    <input type="text" id="search" class="form-control float-right" value="<?php echo e($value); ?>" placeholder="<?php echo e($placeholder); ?>" autofocus onfocus="var temp_value=this.value; this.value=''; this.value=temp_value" link="<?php echo e($link); ?>">
<?php endif; ?>
<?php /**PATH D:\Project\nguyenvanxuanphu\resources\views/_partials/search.blade.php ENDPATH**/ ?>