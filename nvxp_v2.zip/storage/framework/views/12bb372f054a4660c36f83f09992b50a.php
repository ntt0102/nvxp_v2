<?php echo e($slot); ?>

<?php /**PATH D:\Project\nguyenvanxuanphu\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>