<?php
$myUser = Auth::user();
$adminCondition = $myUser && in_array($myUser->role, [branch_manager_role(), administrator_role()]);
?>
<!-- Main Header -->
<nav class="navbar navbar-expand-md bg-<?php echo e($skin); ?>-gradient navbar-<?php echo e($skin == 'warning' ? 'light' : 'dark'); ?> fixed-top ">
  <!-- Logo -->
  <a href="<?php echo e(route('welcome')); ?>" class="mr-5" title="<?php echo e(\App\Utils::checkRoute(['welcome']) ? '': 'Trở về trang chủ'); ?>">
    <span class="text-light <?php echo e(\App\Utils::checkRoute(['welcome']) ? 'active': ''); ?>"><?php echo e(config('adminlte.name')); ?></span>
  </a>
  <!-- Fullscreen On Phone -->
  <!-- <a class="fullscreen load-none d-block d-sm-none" title="Phóng to màn hình" onclick="toggleFullScreen(document.body)"><i class="fas fa-expand"></i></a> -->

  <!-- Toggle Icon -->
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarColor01" aria-controls="navbarColor01" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <!-- Navbar links -->
  <div class="collapse navbar-collapse" id="navbarColor01">
    <!-- Left navbar links -->
    <ul class="navbar-nav mr-auto">
      <li class="nav-item <?php echo e(\App\Utils::checkRoute(['introduction']) ? 'active': ''); ?>">
        <a href="<?php echo e(route('introduction')); ?>" class="nav-link"><i class="fas fa-book"></i> Phả ký</a>
      </li>
      <li class="nav-item <?php echo e(\App\Utils::checkRoute(['map']) ? 'active': ''); ?>">
        <a href="<?php echo e(route('map')); ?>" class="nav-link"><i class="fas fa-sitemap"></i> Phả đồ</a>
      </li>
      <li class="nav-item <?php echo e(\App\Utils::checkRoute(['teaching']) ? 'active': ''); ?>">
        <a href="<?php echo e(route('teaching')); ?>" class="nav-link"><i class="fas fa-book-open"></i> Gia huấn ca</a>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle load-none <?php echo e(\App\Utils::checkRoute(['filter', 'propose', 'statistic', 'uppermap']) ? 'active': ''); ?>" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <i class="nav-icon fas fa-ellipsis-v"></i> Khác
        </a>
        <div class="dropdown-menu">
          <?php if(auth()->guard()->check()): ?>
          <a class="dropdown-item <?php echo e(\App\Utils::checkRoute(['admin::members.create']) ? 'active': ''); ?>" href="<?php echo e(route('admin::members.create')); ?>"><i class="fas fa-user-plus"></i> Thêm người</a>
          <?php endif; ?>
          <a class="dropdown-item <?php echo e(\App\Utils::checkRoute(['filter']) ? 'active': ''); ?>" href="<?php echo e(route('filter')); ?>?filterMode=view"><i class="fas fa-search"></i> Tìm trong phả đồ</a>
          <a class="dropdown-item <?php echo e(\App\Utils::checkRoute(['statistic']) ? 'active': ''); ?>" href="<?php echo e(route('statistic').'?id=1'); ?>"><i class="fas fa-chart-area"></i> Thống kê con cháu</a>
          <a class="dropdown-item <?php echo e(\App\Utils::checkRoute(['propose']) ? 'active': ''); ?>" href="<?php echo e(route('propose', 0)); ?>"><i class="fas fa-comment-dots"></i> Đề xuất sửa đổi</a>
          <a class="dropdown-item <?php echo e(\App\Utils::checkRoute(['uppermap']) ? 'active': ''); ?>" href="<?php echo e(route('uppermap')); ?>"><i class="fas fa-sitemap"></i> Thượng tôn đồ</a>
        </div>
      </li>
    </ul>
    <!-- Right navbar links -->
    <ul class="navbar-nav navbar-right navbar-right-link">
      <?php if(auth()->guard()->guest()): ?>
      <?php if(Route::has('login') && !\App\Utils::checkRoute(['login'])): ?>
      <li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('login')); ?>"><i class="fas fa-sign-in-alt"></i> Quản lý</a>
      </li>
      <?php endif; ?>
      <?php else: ?>
      <?php if(auth()->guard()->check()): ?>
      <li class="nav-item <?php echo e(\App\Utils::checkRoute(['guide']) ? 'active': ''); ?>">
        <a href="<?php echo e(route('guide')); ?>" class="nav-link load-none" target="_blank"><i class="fas fa-question-circle"></i>
          Hướng dẫn</a>
      </li>
      <?php endif; ?>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle load-none" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <img src="<?php echo e(Auth::user()->getAvatarPath()); ?>" alt="profile-photo" class="img-circle elevation-4" width="30px;" style="margin-top: -10px;">&nbsp;
          <?php echo e(Auth::user()->getUserName()); ?>

        </a>
        <div class="dropdown-menu mt-1" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="<?php echo e(route('dashboard::index')); ?>">
            <i class="nav-icon fas fa-tachometer-alt"></i> Quản lý
          </a>
          <a class="dropdown-item" href="<?php echo e(route('admin::members.edit', Auth::user()->getMemberId())); ?>">
            <i class="nav-icon fas fa-user-circle"></i> Hồ sơ cá nhân
          </a>
          <a class="dropdown-item" href="<?php echo e(route('admin::users.change-password')); ?>">
            <i class="nav-icon fas fa-unlock-alt"></i> Đổi mật khẩu
          </a>
          <a class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
            <i class="nav-icon fas fa-sign-out-alt"></i> Đăng xuất
          </a>
          <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
            <?php echo e(csrf_field()); ?>

          </form>
        </div>
      </li>
      <?php endif; ?>
      <!-- <li class="nav-item d-none d-sm-block">
        <a class="nav-link load-none fullscreen" title="Phóng to màn hình" onclick="toggleFullScreen(document.body)"><i class="fas fa-expand"></i></a>
      </li> -->
    </ul>
    <!-- ./navbar-right-->
  </div>
  <!-- ./navbar-collapse -->
</nav><?php /**PATH D:\Project\nguyenvanxuanphu\resources\views/layouts/partials/frontend/header.blade.php ENDPATH**/ ?>