<?php
$color = App\Utils::getColor();
?>




<?php
$_pageTitle = 'Đề xuất';
$_pageTitleLower = mb_strtolower($_pageTitle);
$resourceAlias = 'admin.proposes';
$resourceRoutesAlias = 'admin::proposes';

$tableCounter = 0;
if (count($records) > 0) {
    $tableCounter = ($records->currentPage() - 1) * $records->perPage();
    $tableCounter = $tableCounter > 0 ? $tableCounter : 0;
}
?>


<?php $__env->startSection('breadcrumbs'); ?>
<?php echo Breadcrumbs::render($resourceRoutesAlias); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('page-title', $_pageTitle); ?>


<?php $__env->startSection('head-extras'); ?>
<link rel="stylesheet" href="<?php echo e(asset('dist/_partials/select2/select2.css?update=20190423')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('dist/admin/proposes/proposes.css?update=20190423')); ?>">
<?php if($records && count($records)): ?>
<link rel="stylesheet" href="<?php echo e(asset('dist/_partials/pagination/pagination.css?update=20190423')); ?>">
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <div class="card card-skin card-<?php echo e($color->skin); ?> card-outline">
            <div class="card-header">
                <h3 class="card-title">&nbsp;<span class="d-none d-sm-inline-block">Danh sách</span></h3>
                <!-- Search -->
                <div class="card-tools">
                    <div class="input-group input-group-sm" style="width: 250px;">
                        <?php if ($__env->exists('_partials.search', ['value' => $search, 'link' => route('admin::proposes')])) echo $__env->make('_partials.search', ['value' => $search, 'link' => route('admin::proposes')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <div class="input-group-append">
                            <button type="submit" class="btn btn-skin btn-<?php echo e($color->skin); ?>"><i class="fa fa-search"></i></button>
                        </div>
                    </div>
                </div>
                <!-- END Search -->
            </div>
            <!-- /.card-header -->
            <div class="card-body">
                <?php if(count($records) > 0): ?>
                <?php if ($__env->exists($resourceAlias.'.table')) echo $__env->make($resourceAlias.'.table', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php else: ?>
                <p class="lead pl-3 pt-2">Không tìm thấy <?php echo e($_pageTitleLower); ?> nào.</p>
                <?php endif; ?>
            </div>
            <!-- /.card-body -->
            <?php if(count($records) > 0): ?>
            <?php if ($__env->exists('common.paginate', ['records' => $records, 'show' => $classifies['show'], 'link' =>
            route($resourceRoutesAlias)])) echo $__env->make('common.paginate', ['records' => $records, 'show' => $classifies['show'], 'link' =>
            route($resourceRoutesAlias)], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>
        </div>
        <!-- /.card -->
    </div>
    <!-- /.col-md-9 -->
</div>
<!-- /.row -->
<?php $__env->stopSection(); ?>


<?php $__env->startSection('footer-extras'); ?>
<script src="<?php echo e(asset('plugins/select2/select2.full.min.js')); ?>?update=20190423"></script>
<script src="<?php echo e(asset('dist/_partials/select2/select2.js?update=20190423')); ?>"></script>
<?php if($records && count($records)): ?>
<script src="<?php echo e(asset('dist/_partials/pagination/pagination.js?update=20190423')); ?>"></script>
<?php endif; ?>
<script src="<?php echo e(asset('dist/_partials/search/search.js?update=20190423')); ?>"></script>
<script src="<?php echo e(asset('dist/admin/proposes/proposes.js?update=20190423')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend', ['theme' => $color->theme, 'skin' => $color->skin], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\nguyenvanxuanphu\resources\views/admin/proposes/index.blade.php ENDPATH**/ ?>