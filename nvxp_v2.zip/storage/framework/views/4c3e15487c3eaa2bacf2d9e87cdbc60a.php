<!-- <link rel="stylesheet" href="<?php echo e(asset('dist/_partials/datepicker/datepicker.css')); ?>?update=20190423"> -->
<!-- <link rel="stylesheet" href="<?php echo e(asset('dist/_partials/avatar/avatar.css')); ?>?update=20190423"> -->
<link rel="stylesheet" href="<?php echo e(asset('dist/_partials/select2/select2.css')); ?>?update=20190423">
<link rel="stylesheet" href="<?php echo e(asset('dist/admin/members/form.css')); ?>?update=20190423"><?php /**PATH D:\Project\nguyenvanxuanphu\resources\views/admin/members/header/form.blade.php ENDPATH**/ ?>