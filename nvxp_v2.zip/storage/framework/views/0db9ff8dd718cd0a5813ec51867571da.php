<?php
$skin = App\Utils::getColor()->skin;
?>



<?php $__env->startSection('page-title', 'Phả đồ'); ?>

<?php $__env->startSection('head-extras'); ?>
<link rel="stylesheet" href="<?php echo e(asset('dist/_partials/treeview/treeview.css')); ?>?update=20190423">
<link rel="stylesheet" href="<?php echo e(asset('dist/general/map/map.css')); ?>?update=20190423">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row" style="padding: 0 10px;">
	<div class="col-md-12">
		<h3 class="title">Phả đồ</h3>
		<div class="map-container card card-<?php echo e($skin); ?> card-outline" style="margin-bottom: 0px !important;">
			<div class="card-header">
				<div class="card-title col-md-6">
					<button id="treeToggle" type="button" class="btn btn-sm btn-outline-dark" tree-mode="<?php echo e($treeMode); ?>" scrolltop="0" scrollleft="0"><i class="fas fa-arrows-alt-<?php echo e($treeMode == 'top' ? 'v' : 'h'); ?>"></i> <span class="d-none d-sm-inline-block"><?php echo e($treeMode == 'top' ? 'Dạng dọc' : 'Dạng ngang'); ?></span></button>
				</div>
				<div class="card-tools" style="top: 0.95rem;">
					<span url="<?php echo e(route('filter')); ?>" filterMode="base" class="filter btn btn-sm btn-outline-primary"><i class="fas fa-project-diagram"></i> <span class="d-none d-sm-inline-block">Chọn gốc</span></span>
					<span url="<?php echo e(route('filter')); ?>" filterMode="view" class="filter btn btn-sm btn-outline-danger"><i class="fas fa-street-view"></i> <span class="d-none d-sm-inline-block">Tìm người</span></span>
				</div>
				<!-- /.card-tools -->
			</div>
			<!-- /.card-header -->
			<div class="card-body">
				<div id="treeContainer" class="tab-content table-responsive" url="<?php echo e(route('get-member')); ?>" tree-mode="">
					<div id="idTreeLeft" class="text-left container <?php echo e($treeMode == 'left' ? '' : 'hide'); ?>"><br>
						<ul class="hide" style="margin-top: -20px;margin-left: -20px;">
							<?php echo str_replace('[_]', ' ', $html); ?>

						</ul>
					</div>
					<div id="idTreeTop" class="text-center container <?php echo e($treeMode == 'top' ? '' : 'hide'); ?>"><br>
						<ul class="hide" style="margin-top: -10px;">
							<?php echo str_replace('[_]', '<div></div>', $html); ?>

						</ul>
					</div>
					<div class="zoom-container input-group-append">
						<button id="btn_ZoomOut" class="btn btn-sm btn-dark"><i class="fas fa-minus"></i></button>
						<button id="btn_ZoomReset" class="btn btn-sm btn-dark"><i class="fas fa-sync-alt"></i></button>
						<button id="btn_ZoomIn" class="btn btn-sm btn-dark"><i class="fas fa-plus"></i></button>
						<button id="btn_FullScreen" class="btn btn-sm btn-dark"><i class="fas fa-expand"></i></button>
					</div>
					<!-- /.zoom -->
					<ul class="contextMenu hide">
						<li class="detailInfo"><i class="far fa-eye"></i> Xem thông tin</li>

						<li class="basePoint"><i class="fas fa-project-diagram"></i> Làm điểm gốc</li>
						<li class="viewMark"><i class="fas fa-street-view"></i> Đánh dấu vị trí</li>

						<?php if(auth()->guard()->guest()): ?>
						<li class="propose" url="<?php echo e(route('propose', 'ID')); ?>"><i class="fas fa-user-check"></i> Đề xuất sửa đổi
						</li>
						<?php else: ?>
						<li class="edit" url="<?php echo e(route('admin::members.edit', 'ID')); ?>"><i class="fas fa-user-edit"></i> Chỉnh sửa
						</li>
						<li class="branch" url="<?php echo e(route('admin::classifies.branch')); ?>" redirect="<?php echo e(route('admin::members.create')); ?>"><i class="fas fa-users"></i> Chọn làm chi phái</li>
						<li class="addChild" url="<?php echo e(route('admin::members.create')); ?>"><i class="fas fa-user-plus"></i> Thêm
							<select>
								<option></option>
								<?php $__currentLoopData = $relations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $relation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option value="<?php echo e($relation->value); ?>"><?php echo e($relation->name); ?></option>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</select>
						</li>
						<?php endif; ?>
					</ul>
					<!-- .contextMenu -->
					<ul class="infoPopup hide">
						<li class="name"></li>
						<li>
							<?php if(auth()->guard()->check()): ?>
							<span>
								ID: <span class="memberId"></span>
							</span>
							<br>
							<?php endif; ?>
							<span>
								Phả hệ: <span class="pedigree"></span>
							</span>
							<span>
								<br>
								Quan hệ: <span class="relation"></span>
							</span>
							<span>
								<br>
								<span class="linkTitle" style="font-weight: bold;"></span>: <span class="linkName"></span>
							</span>
							<span>
								<br>
								Ghi chú: <span class="note"></span>
							</span>
						</li>
					</ul>
					<!-- /.infoPopup -->
				</div>
				<!-- /.tab-content -->
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('footer-extras'); ?>
<script src="<?php echo e(asset('plugins/fullscreen/jquery.fullscreen.min.js')); ?>?update=20190423"></script>
<script src="<?php echo e(asset('dist/_partials/treeview/treeview.js')); ?>?update=20190423"></script>
<script src="<?php echo e(asset('dist/general/map/map.js')); ?>?update=20190423"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', ['skin' => $skin], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\nguyenvanxuanphu\resources\views/general/map.blade.php ENDPATH**/ ?>