<?php
$skin = App\Utils::getColor()->skin;
?>



<?php $__env->startSection('page-title', 'Trang chủ'); ?>

<?php $__env->startSection('head-extras'); ?>
<link rel="stylesheet" href="<?php echo e(asset('dist/general/welcome/welcome.css')); ?>?update=20190423">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div style="background: url(<?php echo e(asset('images/welcome.jpg')); ?>) no-repeat center; background-size: cover; height: calc(100vh - 56px); @mobile padding-top: 30px; padding-bottom: 30px; @endmobile">
  <div style="height: 100%; overflow-y: auto; padding: 0 5px; text-align: justify; @notmobile margin-left: 60px; padding-right: 50px; @endnotmobile">
    <?php echo $content; ?>

  </div>
</div>
<?php if(auth()->guard()->check()): ?>
<?php if(Auth::user()->role == 2): ?>
<div class="card-footer" style="background: white">
  <a target="_blank" class="load-none" href="<?php echo e(route('admin::constants.edit', 7)); ?>">Chỉnh sửa <i class="far fa-edit"></i></a>
</div>
<?php endif; ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('footer-extras'); ?>
<script src="<?php echo e(asset('dist/general/welcome/welcome.js')); ?>?update=20190423"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', ['skin' => $skin], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\nguyenvanxuanphu\resources\views/general/welcome.blade.php ENDPATH**/ ?>