<div class="row">
    <div class="col-md-3">
        <div class="form-group">
            <label for="type" class="form-control-label">Loại thao tác</label>
            <select id="type" class="form-control load">
                <option value="">&nbsp;</option>
                <?php $__currentLoopData = $classifies['types']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($type->value); ?>" <?php echo e($classifies['type'] == $type->value ? 'selected' : ''); ?>><?php echo e($type->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <!-- form-group -->
    </div>
    <!-- col-md-3 -->
</div>
<!-- row --><?php /**PATH D:\Project\nguyenvanxuanphu\resources\views/admin/logs/filter.blade.php ENDPATH**/ ?>