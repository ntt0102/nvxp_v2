<?php
  $skin = App\Utils::getColor()->skin;
?>



<?php $__env->startSection('page-title', 'Quên mật khẩu'); ?>
<!-- Main content -->
<?php $__env->startSection('content'); ?>

<?php if(session('status')): ?> 
    <div class="alert alert-success mt-3" >
        Chúng tôi đã gửi đường dẫn đặt lại mật khẩu tới email của bạn. Nếu không nhận được email xin vui lòng gửi lại.
    </div>
<?php endif; ?>
<div class="login-box">
    <div class="card card-<?php echo e($skin); ?> card-outline">
        <div class="card-header">
          <p class="card-title text-center">Đặt lại mật khẩu</p>
        </div>
        <!-- /.card-header --> 
        <div class="card-body">
            <form id="email-form" method="POST" action="<?php echo e(route('password.email')); ?>">
                <?php echo e(csrf_field()); ?>


                <div class="row">
                    <div class="col-md-12">
                        <div class="form-group">
                            <label for="email" class="form-control-label">Email</label>
                            <input id="email" type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$" required autofocus>
                            <?php if($errors->has('email')): ?>
                                <div class="invalid-feedback">Email <?php echo e($errors->first('email')); ?></div>
                            <?php endif; ?>
                        </div>
                        <!-- /.form-group -->
                    </div>
                    <!-- col-md-12 -->
                </div>
                <!-- row -->
                <div class="row">
                    <div class="col-md-12">
                        <div class="form-group">
                            <button type="submit" class="btn btn-<?php echo e($skin); ?>">Gửi email</button>
                        </div>
                        <p>Hoặc liên hệ với ban quản lý trang web.</p>
                        <!-- /.form-group -->
                    </div>
                    <!-- col-md-12 -->
                </div>
                <!-- row -->
            </form>
            <!-- /form -->
        </div>
        <!-- /.card-body -->
        <div class="card-footer">
            <p class="text-center"><em>Nếu bạn còn nhớ mật khẩu thì hãy bấm vào <a href="<?php echo e(route('login')); ?>">đây</a> để đăng nhập hoặc <a href="<?php echo e(route('welcome')); ?>">quay về trang chủ</a></em></p>
        </div>
        <!-- /.card-footer -->
    </div>
    <!-- /.card -->
</div>
<!-- /.login-box -->
<?php $__env->stopSection(); ?>


<?php $__env->startSection('footer'); ?>
  <?php if ($__env->exists('layouts.partials.frontend.footer2')) echo $__env->make('layouts.partials.frontend.footer2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', ['skin' => $skin], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\nguyenvanxuanphu\resources\views/auth/passwords/email.blade.php ENDPATH**/ ?>