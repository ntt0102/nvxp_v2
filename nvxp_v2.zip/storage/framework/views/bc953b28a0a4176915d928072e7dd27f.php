<?php
  $skin = App\Utils::getColor()->skin;
?>


<?php $__env->startSection('title', 'Lỗi 404'); ?>

<?php $__env->startSection('code', '404'); ?>
<?php $__env->startSection('message', 'Xin lỗi, trang này không tìm thấy.'); ?>

<?php echo $__env->make('layouts.errors', ['skin' => $skin], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\nguyenvanxuanphu\resources\views/errors/404.blade.php ENDPATH**/ ?>