<?php if($myUser->role == 2): ?>
    <div class="col-md-9">
        <form id="formCommand" role="form" method="POST" action="<?php echo e($commandLink); ?>">
            <?php echo e(csrf_field()); ?>

            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="command" class="form-control-label">Lệnh</label>
                        <select id="command" name="command" class="form-control<?php echo e($errors->has('command') ? ' is-invalid' : ''); ?>">
                            <option value="">&nbsp;</option>
                            <?php $__currentLoopData = $commands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $command): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($command->value); ?>" <?php echo e(old('command') == $command->value ? 'selected' : ''); ?>><?php echo e($command->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php if($errors->has('command')): ?>
                            <div class="invalid-feedback">Lệnh <?php echo e($errors->first('command')); ?></div>
                        <?php endif; ?>
                    </div>
                    <!-- /.form-group -->
                </div>
                <!-- col-md-6 -->
            </div>
            <!-- row -->
        </form>
    </div>
    <!-- /.col-md-9 -->
<?php else: ?>
    <p>Không được phép truy cập</p>
<?php endif; ?>
<?php /**PATH D:\Project\nguyenvanxuanphu\resources\views/admin/command/form.blade.php ENDPATH**/ ?>