<?php if(!($myUser->role == 1 && $record->upperFlag)): ?>
<div class="col-md-12">
    <div class="row">
        <?php if(!($record->id || $classifies['upperFlag'] || isset($classifies['parent']) || isset($classifies['couple']))): ?>
        <div class="col-md-5">
            <div class="form-group">
                <label for="branch" class="form-control-label">
                    Chi phái
                    <i class="far fa-question-circle" title="Chọn chi phái gần nhất để tải dữ liệu nhanh hơn"></i>
                    <a target="_blank" class="load-none" href="<?php echo e(route('admin::classifies.index').'?constant=4'); ?>" style="font-style: italic;" title="Tải lại trang sau khi chỉnh sửa">
                        (Chỉnh sửa)
                    </a>
                </label>
                <select id="branch" name="branch" class="form-control<?php echo e($errors->has('branch') ? ' is-invalid' : ''); ?>">
                    <option value="">&nbsp;</option>
                    <?php
                    if (!isset($classifies['branch']) && count($classifies['branches']) == 1) {
                        $classifies['branch'] = $classifies['branches'][0]->id;
                    }
                    ?>
                    <?php $__currentLoopData = $classifies['branches']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($branch->id); ?>" <?php echo e(old('branch', isset($classifies['branch']) ? $classifies['branch'] : "" ) == $branch->id ? 'selected' : ''); ?>><?php echo e($branch->name.' (Hệ '.$branch->pedigree.')'); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('branch')): ?>
                <div class="invalid-feedback">Chi phái <?php echo e($errors->first('branch')); ?></div>
                <?php endif; ?>
            </div>
            <!-- /.form-group -->
        </div>
        <!-- col-md-5 -->
        <?php endif; ?>
        <?php if($record->id): ?>
        <div class="col-md-5">
            <div class="form-group">
                <label for="id" class="form-control-label">ID</label>
                <div class="form-control"><span id="id"><?php echo e($record->id); ?></span>
                    <?php if(!$record->upperFlag): ?>
                    <a class="float-right" href=" <?php echo e(route('map').'?view='.$record->id); ?>"><i class="fas fa-sitemap"></i> Xem</a>
                    <?php endif; ?>
                </div>
            </div>
            <!-- /.form-group -->
        </div>
        <!-- col-md-5 -->
        <?php endif; ?>
        <?php if($myUser->role == 2): ?>
        <div class="col-md-2">
            <div class="form-group">
                <label for="upperFlag" class="form-control-label d-none d-md-block">&nbsp;</label>
                <div class="custom-control custom-checkbox dead-flag">
                    <input type="checkbox" class="custom-control-input" id="upperFlag" name="upperFlag" <?php echo e(old('upperFlag', isset($classifies['upperFlag']) ? $classifies['upperFlag'] : ($record->id ? $record->upperFlag : '')) ? 'checked' : ''); ?>>
                    <label class="custom-control-label" for="upperFlag">Cao hệ</label>
                </div>
                <!-- /.custom-control -->
            </div>
            <!-- /.form-group -->
        </div>
        <!-- col-md-5 -->
        <?php endif; ?>
    </div>
    <div class="row">
        <div class="col-md-5">
            <div class="form-group">
                <label for="pedigree" class="form-control-label">Hệ</label>
                <select id="pedigree" name="pedigree" class="form-control<?php echo e($errors->has('pedigree') ? ' is-invalid' : ''); ?>">
                    <option value="">&nbsp;</option>
                    <?php for($i = $classifies['pedigrees'][0]; $i <= $classifies['pedigrees'][1]; $i++): ?> <option value="<?php echo e($i); ?>" <?php echo e(old('periods', isset($classifies['pedigree']) ? $classifies['pedigree'] : $record->pedigree ) == $i ? 'selected' : ''); ?>><?php echo e($i); ?></option>
                        <?php endfor; ?>
                </select>
                <?php if($errors->has('pedigree')): ?>
                <div class="invalid-feedback">Hệ <?php echo e($errors->first('pedigree')); ?></div>
                <?php endif; ?>
            </div>
            <!-- /.form-group -->
        </div>
        <!-- col-md-5 -->
        <div class="col-md-5">
            <div class="form-group">
                <label for="relation" class="form-control-label">Quan hệ gia phả</label>
                <select id="relation" name="relation" class="form-control<?php echo e($errors->has('relation') ? ' is-invalid' : ''); ?>">
                    <option value="">&nbsp;</option>
                    <?php $__currentLoopData = $classifies['relations']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $relation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($relation->value); ?>" <?php echo e(old('relation', isset($classifies['relation']) ? $classifies['relation'] : $record->relation ) == $relation->value ? 'selected' : ''); ?>><?php echo e($relation->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('relation')): ?>
                <div class="invalid-feedback">Quan hệ gia phả <?php echo e($errors->first('relation')); ?></div>
                <?php endif; ?>
            </div>
            <!-- /.form-group -->
        </div>
        <!-- col-md-5 -->
    </div>
    <!-- ./row -->
    <?php if(isset($classifies['relation'])): ?>
    <div class="row">
        <div class="col-md-5">
            <div class="form-group">
                <label for="name" class="form-control-label">Họ tên</label>
                <input id="name" type="text" class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" name="name" value="<?php echo e(old('name', $record->name)); ?>" required autofocus onfocus="var temp_value=this.value; this.value=''; this.value=temp_value">
                <?php if($errors->has('name')): ?>
                <div class="invalid-feedback">Họ tên <?php echo e($errors->first('name')); ?></div>
                <?php endif; ?>
            </div>
            <!-- /.form-group -->
        </div>
        <!-- col-md-5 -->
        <div class="col-md-5 hide">
            <div class="form-group">
                <label for="gender" class="form-control-label">Giới tính</label>
                <select id="gender" name="gender" class="form-control<?php echo e($errors->has('gender') ? ' is-invalid' : ''); ?>">
                    <option value="">&nbsp;</option>
                    <?php $__currentLoopData = $classifies['genders']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gender): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($gender->value); ?>" <?php echo e(old('gender', isset($classifies['gender']) ? $classifies['gender'] : $record->gender ) == $gender->value ? 'selected' : ''); ?>><?php echo e($gender->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('gender')): ?>
                <div class="invalid-feedback">Giới tính <?php echo e($errors->first('gender')); ?></div>
                <?php endif; ?>
            </div>
            <!-- /.form-group -->
        </div>
        <!-- col-md-5 -->
    </div>
    <!-- row -->
    <div class="row">
        <?php if(isset($classifies['parents'])): ?>
        <div class="col-md-5">
            <div class="form-group">
                <label for="parent" class="form-control-label">Cha <i class="far fa-question-circle" title="Nếu không tìm thấy cha hãy chọn Chi phái"></i></label>
                <select id="parent" name="parent" class="form-control<?php echo e($errors->has('parent') ? ' is-invalid' : ''); ?>">
                    <option value="">&nbsp;</option>
                    <?php
                    if (!isset($classifies['parent']) && count($classifies['parents']) == 1) {
                        $classifies['parent'] = $classifies['parents'][0]->id;
                    }
                    ?>
                    <?php $__currentLoopData = $classifies['parents']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($parent->id); ?>" <?php echo e(old('parent', isset($classifies['parent']) ? $classifies['parent'] : $record->parent_id) == $parent->id ? 'selected' : ''); ?>><?php echo e($parent->name.($parent->parent_name ? ' ('.$parent->parent_name.')' : '')); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('parent')): ?>
                <div class="invalid-feedback">Cha <?php echo e($errors->first('parent')); ?></div>
                <?php endif; ?>
            </div>
            <!-- /.form-group -->
        </div>
        <!-- col-md-5 -->
        <div class="col-md-5">
            <div class="form-group">
                <label for="ordinal_brother" class="form-control-label">Thứ tự anh em</label>
                <input id="ordinal_brother" type="number" class="form-control<?php echo e($errors->has('ordinal_brother') ? ' is-invalid' : ''); ?>" name="ordinal_brother" value="<?php echo e(old('ordinal_brother', $record->ordinal_brother)); ?>">
                <?php if($errors->has('ordinal_brother')): ?>
                <div class="invalid-feedback">Thứ tự anh em <?php echo e($errors->first('ordinal_brother')); ?></div>
                <?php endif; ?>
            </div>
            <!-- /.form-group -->
        </div>
        <!-- col-md-5 -->
        <?php endif; ?>

        <?php if($classifies['pedigree'] != 1): ?>
        <?php if(isset($classifies['couples'])): ?>
        <div class="col-md-5">
            <div class="form-group">
                <label for="couple" class="form-control-label"><?php echo e($classifies['gender']%2 ? 'Vợ' : 'Chồng'); ?> <i class="far fa-question-circle" title="Nếu không tìm thấy <?php echo e($classifies['gender']%2 ? 'vợ' : 'chồng'); ?> hãy chọn Chi phái"></i></label>
                <select id="couple" name="couple" class="form-control<?php echo e($errors->has('couple') ? ' is-invalid' : ''); ?>">
                    <option value="">&nbsp;</option>
                    <?php $__currentLoopData = $classifies['couples']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $couple): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($couple->id); ?>" <?php echo e(old('couple', isset($classifies['couple']) ? $classifies['couple'] : $record->couple_id) == $couple->id ? 'selected' : ''); ?>><?php echo e($couple->name.($couple->parent_name ? ' (Cha '.$couple->parent_name.')' : '')); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('couple')): ?>
                <div class="invalid-feedback"><?php echo e($classifies['gender']%2 ? 'Vợ' : 'Chồng'); ?> <?php echo e($errors->first('couple')); ?></div>
                <?php endif; ?>
            </div>
            <!-- /.form-group -->
        </div>
        <!-- col-md-5 -->
        <?php endif; ?>
        <div class="col-md-5">
            <div class="form-group">
                <label for="marriage_step" class="form-control-label">Đời <?php echo e(isset($classifies['parents']) ? 'mẹ' : ($classifies['gender']%2 ? 'chồng' : 'vợ')); ?> <i class="far fa-question-circle" title="Nếu chỉ có một đời thì không cần nhập"></i></label>
                <input id="marriage_step" type="number" class="form-control<?php echo e($errors->has('marriage_step') ? ' is-invalid' : ''); ?>" name="marriage_step" value="<?php echo e(old('marriage_step', $record->marriage_step)); ?>">
                <?php if($errors->has('marriage_step')): ?>
                <div class="invalid-feedback">Đời <?php echo e(isset($classifies['parents']) ? 'mẹ' : ($classifies['gender']%2 ? 'chồng' : 'vợ')); ?> <?php echo e($errors->first('marriage_step')); ?></div>
                <?php endif; ?>
            </div>
            <!-- /.form-group -->
        </div>
        <!-- col-md-5 -->
        <?php endif; ?>
    </div>
    <!-- ./row -->
    <!-- row -->
    <div class="row">
        <div class="col-md-10">
            <div class="form-group">
                <label for="note" class="form-control-label">Ghi chú</label>
                <textarea id="note" name="note" class="form-control<?php echo e($errors->has('note') ? ' is-invalid' : ''); ?>" rows="3"><?php echo e(old('note', $record->note)); ?></textarea>
                <?php if($errors->has('note')): ?>
                <div class="invalid-feedback">Ghi chú <?php echo e($errors->first('note')); ?></div>
                <?php endif; ?>
            </div>
            <!-- /.form-group -->
        </div>
        <!-- col-md-5 -->
    </div>
    <!-- row -->
    <?php endif; ?>
</div>
<!-- /.col-md-12 -->
<input type="hidden" name="classifies" />
<input type="hidden" id="page" value="<?php echo e($classifies['page']); ?>" />
<?php
$hasChilds = 0;
if ($record->id) {
    $childs = App\Utils::getChildMembers($record->id);
    $hasChilds = count($childs);
}
?>
<?php if(isset($hasChilds) && $hasChilds > 0): ?>
<input type="hidden" id="isDelete" value="<?php echo e($hasChilds); ?>" />
<?php endif; ?>

<?php else: ?>
<p>Không được phép truy cập</p>
<?php endif; ?><?php /**PATH D:\Project\nguyenvanxuanphu\resources\views/admin/members/form.blade.php ENDPATH**/ ?>