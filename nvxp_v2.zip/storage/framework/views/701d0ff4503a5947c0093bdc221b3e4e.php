<?php
$color = App\Utils::getColor();
//
$myUser = Auth::user();
?>





<?php $__env->startSection('breadcrumbs'); ?>
<?php echo Breadcrumbs::render('admin'); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('page-title', 'Tổng quan'); ?>


<?php $__env->startSection('head-extras'); ?>
<link rel="stylesheet" href="<?php echo e(asset('dist/admin/index.css')); ?>?update=20190423">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
  <div class="col-12">
    <div class="card card-skin card-<?php echo e($color->skin); ?> card-outline">
      <div class="card-body">
        <div class="group">
          <div class="item row">
            <div class="title">Tổng số hệ:</div>
            <div class="value"><?php echo e($report->getPedigrees()); ?></div>
          </div>
        </div>
        <div class="group">
          <div class="item row">
            <div class="title">Tổng số thành viên:</div>
            <div class="value"><?php echo e($report->getMembers()); ?></div>
          </div>
        </div>
        <div class="group">
          <div class="item row">
            <div class="title">Tổng số con trai:</div>
            <div class="value"><?php echo e($report->getSons()); ?></div>
          </div>
        </div>
        <div class="group">
          <div class="item row">
            <div class="title">Tổng số con gái:</div>
            <div class="value"><?php echo e($report->getDaughters()); ?></div>
          </div>
        </div>
        <div class="group">
          <div class="item row">
            <div class="title">Tổng số con dâu:</div>
            <div class="value"><?php echo e($report->getDaughterInLaws()); ?></div>
          </div>
        </div>
        <!-- /.card-body-->
      </div>
    </div>
    <!-- /.card -->
  </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('footer-extras'); ?>
<script src="<?php echo e(asset('dist/admin/index.js')); ?>?update=20190423"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend', ['theme' => $color->theme, 'skin' => $color->skin], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\nguyenvanxuanphu\resources\views/admin/index.blade.php ENDPATH**/ ?>