<?php
$skin = App\Utils::getColor()->skin;
?>



<?php $__env->startSection('page-title', 'Đặt lại mật khẩu'); ?>
<!-- Main content -->
<?php $__env->startSection('content'); ?>
<div class="login-box">
    <div class="card card-<?php echo e($skin); ?> card-outline">
        <div class="card-header">
            <p class="card-title text-center">Đổi mật khẩu mới</p>
        </div>
        <!-- /.card-header -->
        <div class="card-body login-card-body1">
            <form method="POST" action="<?php echo e(route('password.request')); ?>">
                <?php echo e(csrf_field()); ?>


                <input type="hidden" name="token" value="<?php echo e($request->route('token')); ?>">

                <div class="row">
                    <div class="col-md-12">
                        <div class="form-group">
                            <label for="email" class="form-control-label">Email</label>
                            <input id="email" type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$" required autofocus>
                            <?php if($errors->has('email')): ?>
                            <div class="invalid-feedback"><?php echo e($errors->first('email')); ?></div>
                            <?php endif; ?>
                        </div>
                        <!-- /.form-group -->
                    </div>
                    <!-- col-md-12 -->
                </div>
                <!-- row -->
                <div class="row">
                    <div class="col-md-12">
                        <div class="form-group">
                            <label for="password" class="form-control-label">Mật khẩu</label>
                            <input id="password" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" value="<?php echo e(old('password')); ?>" required>
                            <?php if($errors->has('password')): ?>
                            <div class="invalid-feedback">Mật khẩu <?php echo e($errors->first('password')); ?></div>
                            <?php endif; ?>
                        </div>
                        <!-- /.form-group -->
                    </div>
                    <!-- col-md-12 -->
                </div>
                <!-- row -->
                <div class="row">
                    <div class="col-md-12">
                        <div class="form-group">
                            <label for="password-confirm" class="form-control-label">Xác nhận mật khẩu</label>
                            <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required>
                        </div>
                        <!-- /.form-group -->
                    </div>
                    <!-- col-md-12 -->
                </div>
                <!-- row -->
                <div class="row">
                    <div class="col-md-12">
                        <div class="form-group">
                            <button type="submit" class="btn btn-<?php echo e($skin); ?>">Đặt lại mật khẩu</button>
                        </div>
                        <!-- /.form-group -->
                    </div>
                    <!-- col-md-12 -->
                </div>
                <!-- row -->
            </form>
            <!-- /form -->
        </div>
        <!-- /.card-body -->
    </div>
    <!-- /.card -->
</div>
<!-- /.login-box -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', ['skin' => $skin], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\nguyenvanxuanphu\resources\views/auth/passwords/reset.blade.php ENDPATH**/ ?>